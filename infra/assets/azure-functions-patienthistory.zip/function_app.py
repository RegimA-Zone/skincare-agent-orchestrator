# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

import json
import logging
import os
import textwrap

import azure.functions as func
from azure.core.exceptions import ResourceNotFoundError
from azure.identity.aio import (DefaultAzureCredential,
                                get_bearer_token_provider)
from azure.storage.blob.aio import BlobServiceClient
from azure.storage.queue import (BinaryBase64DecodePolicy,
                                 BinaryBase64EncodePolicy)
from azure.storage.queue.aio import QueueClient
from openai import AsyncAzureOpenAI
from openai.types.chat import ChatCompletionMessage

from data_models.chat_artifact import (ChatArtifact, ChatArtifactFilename,
                                       ChatArtifactIdentifier)
from data_models.data_access import DataAccess
from data_models.patient_timeline import (PatientTimeline,
                                          PatientTimelineEntrySource)
from evidence import Evidence, find_evidence

app = func.FunctionApp()


@app.function_name(name="CreatePatientTimeline")
@app.queue_trigger(arg_name="msg", queue_name="create-patient-timeline-input", connection="STORAGE_CONNECTION")
async def create_patient_timeline(msg: func.QueueMessage) -> None:
    logging.info('Python queue trigger function create_patient_timeline')

    try:
        credential = _get_credential()

        # Queue to send message to
        queue_client = _get_queue_client("create-patient-timeline-output", credential)

        # Blob to load patient data
        data_access = _get_data_access(credential)
        logging.info("Connected to blob storage")

        messagepayload = json.loads(msg.get_body().decode('utf-8'))
        patient_id = messagepayload['patient_id']
        correlation_id = messagepayload['CorrelationId']
        logging.info(f"patient_id: {patient_id}, correlation_id: {correlation_id}")

        files = await data_access.clinical_note_accessor.read_all(patient_id)
        completion = await _get_patient_timeline_completion(credential, files)
        timeline = completion.parsed
        timeline.patient_id = patient_id

        # Save patient timeline
        artifact_id = ChatArtifactIdentifier(
            conversation_id=msg.id,
            patient_id=patient_id,
            filename=ChatArtifactFilename.PATIENT_TIMELINE_FILENAME
        )
        artifact = ChatArtifact(artifact_id, data=completion.content.encode('utf-8'))
        await data_access.chat_artifact_accessor.write(artifact)

        # Format the timeline for display
        response = ""
        indent = " " * 4
        for entry_index, entry in enumerate(timeline.entries):
            response += f"- {entry.date}: {entry.title}\n"
            response += f"{indent}- {entry.description}\n"
            for src_idx, src in enumerate(entry.sources):
                note_url = _get_patient_timeline_entry_source_url(msg.id, patient_id, entry_index, src_idx)
                source_text = " ".join(src.sentences) if src.sentences else "No text provided"
                shortened_source_text = textwrap.shorten(source_text, width=160, placeholder="\u2026")
                response += f"{indent}- Source: [{shortened_source_text}]({note_url})\n"

        # Send patient data to output queue
        result_message = {
            'Value': response,
            'CorrelationId': correlation_id
        }
        await queue_client.send_message(json.dumps(result_message).encode('utf-8'))
    except:
        logging.exception("Error creating patient timeline")
        raise


@app.function_name(name="ProcessPrompt")
@app.queue_trigger(arg_name="msg", queue_name="process-prompt-input", connection="STORAGE_CONNECTION")
async def process_prompt(msg: func.QueueMessage) -> None:
    try:
        credential = _get_credential()

        # Queue to send message to
        queue_client = _get_queue_client("process-prompt-output", credential)

        # Blob to load patient data
        data_access = _get_data_access(credential)
        logging.info("Connected to blob storage")

        messagepayload = json.loads(msg.get_body().decode('utf-8'))
        patient_id = messagepayload['patient_id']
        prompt = messagepayload['prompt']
        correlation_id = messagepayload['CorrelationId']
        logging.info(f"patient_id: {patient_id}, correlation_id: {correlation_id}")

        files = await data_access.clinical_note_accessor.read_all(patient_id)
        completion = await _get_patient_answer_completion(credential, files, prompt)

        # Send patient data to output queue
        result_message = {
            'Value': str(completion.content),
            'CorrelationId': correlation_id
        }
        await queue_client.send_message(json.dumps(result_message).encode('utf-8'))
    except:
        logging.exception("Error processing prompt")
        raise


@app.function_name(name="ViewPatientTimeline")
@app.route(route="view/{conversation_id:guid}/{patient_id}/timeline/entry/{entry_index:int}/source/{src_index:int}.html",
           methods=[func.HttpMethod.GET], auth_level=func.AuthLevel.ANONYMOUS)
async def view_patient_timeline(req: func.HttpRequest) -> func.HttpResponse:
    try:
        conversation_id = req.route_params.get("conversation_id")
        patient_id = req.route_params.get("patient_id")
        entry_index = int(req.route_params.get("entry_index"))
        src_index = int(req.route_params.get("src_index"))

        credential = _get_credential()
        data_access = _get_data_access(credential)

        # Load patient timeline
        artifact_id = ChatArtifactIdentifier(
            conversation_id=conversation_id,
            patient_id=patient_id,
            filename=ChatArtifactFilename.PATIENT_TIMELINE_FILENAME
        )
        artifact = await data_access.chat_artifact_accessor.read(artifact_id)
        artifact_json = artifact.data.decode('utf-8')
        patient_timeline = PatientTimeline.model_validate_json(artifact_json)
        entry = patient_timeline.entries[entry_index]
        source = entry.sources[src_index]

        # Get the clinical note
        note_id = source.note_id
        note = await data_access.clinical_note_accessor.read(patient_id, note_id)
        note_dict = json.loads(note)

        evidences = _find_evidences_in_source(note_dict, source)
        highlighted_note_text = _highlight_note_text(note_dict["text"], evidences) if evidences \
            else note_dict.get("text", "No text provided")

        body = f"""
            <html>
                <head>
                    <title>Clinical Note</title>
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <style>
                        html {{
                            margin: auto;
                            max-width: 800px;
                        }}
                        pre {{
                            white-space: pre-wrap;
                        }}
                        .highlight {{
                            background-color: yellow; /* Highlight color for evidence */
                            border-radius: 3px;
                            padding: 0 2px;
                        }}
                    </style>
                </head>
                <body>
                    <h1>Clinical Note</h1>
                    <p>Patient ID: {patient_id}</p>
                    <p>Note ID: {note_id}</p>
                    <p>Date: {note_dict.get("date", "N/A")}</p>
                    <p>Note Type: {note_dict.get("note_type", "N/A")}</p>
                    <pre>{highlighted_note_text}</pre>
                </body>
            </html>
        """
        return func.HttpResponse(body, status_code=200, mimetype="text/html")
    except ResourceNotFoundError:
        return func.HttpResponse("Patient timeline not found", status_code=404)
    except:
        logging.exception("Error viewing patient timeline")
        return func.HttpResponse("Error creating patient timeline view", status_code=500)


def _get_credential() -> DefaultAzureCredential:
    return DefaultAzureCredential(
        managed_identity_client_id=os.getenv("AZURE_CLIENT_ID")
    )


def _get_data_access(credential: DefaultAzureCredential) -> DataAccess:
    blob_service_client = BlobServiceClient(
        account_url=os.getenv("STORAGE_CONNECTION__patientDataBlobServiceUri"),
        credential=credential,
    )
    return DataAccess(blob_service_client)


async def _get_patient_timeline_completion(credential: DefaultAzureCredential, clinical_notes: list[str]) -> ChatCompletionMessage:
    openai_client = AsyncAzureOpenAI(
        api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        azure_ad_token_provider=get_bearer_token_provider(credential, "https://cognitiveservices.azure.com/.default")
    )

    try:
        # https://openai.com/index/introducing-structured-outputs-in-the-api/
        completion = await openai_client.beta.chat.completions.parse(
            model=os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT_NAME"),
            messages=[
                {
                    "role": "system",
                    "content": "Create a Patient Timeline: Organize the patient data in chronological order to create a clear timeline " +
                    "of the patient's medical history and treatment. Use the provided clinical notes. Add the referenced " +
                    "clinical note as a source. A source may contain multiple multiple sentences."
                },
                {
                    "role": "system",
                    "content": "You have access to the following patient history:\n" + json.dumps(clinical_notes)
                }
            ],
            response_format=PatientTimeline,
            max_completion_tokens=10000,
            temperature=0,
            top_p=1,
        )
        return completion.choices[0].message
    finally:
        openai_client.close()


def _get_patient_timeline_entry_source_url(conversation_id: str, patient_id: str, entry_index: int, src_index: int) -> str:
    hostname = os.getenv("APP_HOSTNAME")
    return f"https://{hostname}/api/view/{conversation_id}/{patient_id}/timeline/entry/{entry_index}/source/{src_index}.html"


async def _get_patient_answer_completion(credential: DefaultAzureCredential, clinical_notes: list[str], prompt: str) -> ChatCompletionMessage:
    openai_client = AsyncAzureOpenAI(
        api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        azure_ad_token_provider=get_bearer_token_provider(credential, "https://cognitiveservices.azure.com/.default")
    )

    try:
        completion = await openai_client.chat.completions.create(
            model=os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT_NAME"),
            messages=[
                {
                    "role": "system",
                    "content": "When answering files, always base the answer strictly on the patient's history. You may infer the answer if it is not directly available. Provide your reasoning if you have inferred the answer. You have access to the following patient history:\n" + json.dumps(clinical_notes)
                },
                {
                    "role": "system",
                    "content": prompt
                }
            ],
            max_completion_tokens=10000,
            temperature=0,
            top_p=1,
        )
        return completion.choices[0].message
    finally:
        openai_client.close()


def _get_queue_client(name: str, credential: DefaultAzureCredential) -> QueueClient:
    return QueueClient(
        os.environ["STORAGE_CONNECTION__queueServiceUri"],
        queue_name=name,
        credential=credential,
        message_encode_policy=BinaryBase64EncodePolicy(),
        message_decode_policy=BinaryBase64DecodePolicy()
    )


def _find_evidences_in_source(note_dict: dict, source: PatientTimelineEntrySource) -> list[Evidence]:
    if "text" not in note_dict:
        return []
    if source is None:
        return []
    if source.sentences is None or len(source.sentences) == 0:
        return []

    evidences = []
    for sentence in source.sentences:
        # Skip None sentences to avoid errors
        if sentence is None:
            continue

        evidence = find_evidence(sentence, note_dict["text"])
        if evidence:
            evidences.append(evidence)

    return evidences


def _highlight_note_text(note_text: str, evidences: list[Evidence]) -> str:
    """
    Highlight the clinical note text based on the provided evidences.

    Args:
        note_text (str): The clinical note text.
        evidences (list[Evidence]): List of evidence objects to highlight in the note.

    Returns:
        str: The highlighted clinical note text.
    """
    highlighted_note_text = ""
    highlighted_note_text_index = 0

    for evidence in evidences:
        # Add the text before the evidence to the highlighted note text
        highlighted_note_text += note_text[highlighted_note_text_index:evidence.begin]
        highlighted_note_text_index = evidence.begin

        # Highlight the evidence in the note text
        highlighted_note_text += f"<span class=\"highlight\">{note_text[evidence.begin:evidence.end]}</span>"
        highlighted_note_text_index = evidence.end

    # Add the remaining text after the last evidence
    highlighted_note_text += note_text[highlighted_note_text_index:]

    return highlighted_note_text
