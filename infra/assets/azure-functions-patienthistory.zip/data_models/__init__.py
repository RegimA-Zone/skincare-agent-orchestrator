# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

from .data_access import DataAccess

__all__ = ["DataAccess"]
