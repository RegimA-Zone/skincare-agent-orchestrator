# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

from pydantic import BaseModel


class PatientTimelineEntrySource(BaseModel):
    note_id: str
    sentences: list[str]


class PatientTimelineEntry(BaseModel):
    date: str
    title: str
    description: str
    sources: list[PatientTimelineEntrySource]


class PatientTimeline(BaseModel):
    patient_id: str
    entries: list[PatientTimelineEntry]
