from dataclasses import dataclass


class ChatArtifactFilename:
    PATIENT_TIMELINE_FILENAME = "patient_timeline.json"


@dataclass(frozen=True)
class ChatArtifactIdentifier:
    conversation_id: str
    patient_id: str
    filename: str


@dataclass(frozen=True)
class ChatArtifact:
    artifact_id: ChatArtifactIdentifier
    data: bytes
