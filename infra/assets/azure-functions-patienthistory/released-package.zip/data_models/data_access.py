
from azure.storage.blob.aio import BlobServiceClient

from data_models.chat_artifact_accessor import ChatArtifactAccessor
from data_models.clinical_note_accessor import ClinicalNoteAccessor


class DataAccess:
    def __init__(self, blob_service_client: BlobServiceClient):
        self.chat_artifact_accessor = ChatArtifactAccessor(blob_service_client)
        self.clinical_note_accessor = ClinicalNoteAccessor(blob_service_client)
